/* ============================================================
   CareerHub – app.js  (all features, no external dependencies)
   ============================================================ */

// ===================== DATA =====================
const DATA = {
  jobs: [
    { id: 1, title: 'UI/UX Designer Intern', company: 'Gojek', logo: '🟢', location: 'Jakarta, Indonesia', type: 'Magang', time: '2 hari lalu', desc: 'Kami mencari UI/UX Designer Intern yang passionate...', req: ['Familiar dengan Figma & Adobe XD','Portofolio desain','Komunikasi yang baik'], resp: ['Membuat wireframe & prototype','Kolaborasi dengan developer','Melakukan user research'], saved: false },
    { id: 2, title: 'Product Designer Intern', company: 'Tokopedia', logo: '🟠', location: 'Jakarta, Indonesia', type: 'Magang', time: '3 hari lalu', desc: 'Tokopedia mencari Product Designer Intern berbakat...', req: ['Portfolio desain produk','Pengalaman Figma min. 1 tahun','Bisa bekerja dalam tim'], resp: ['Mendesain fitur produk baru','Melakukan usability test','Dokumentasi desain'], saved: false },
    { id: 3, title: 'Data Analyst Intern', company: 'BCA', logo: '🔵', location: 'Jakarta, Indonesia', type: 'Magang', time: '5 hari lalu', desc: 'BCA membuka lowongan untuk Data Analyst Intern...', req: ['Familiar dengan SQL & Python','Kemampuan analisis data','IPK min. 3.0'], resp: ['Menganalisis data transaksi','Membuat laporan reguler','Presentasi insight kepada stakeholder'], saved: false },
    { id: 4, title: 'Digital Marketing Intern', company: 'Ruangguru', logo: '🟡', location: 'Jakarta, Indonesia', type: 'Magang', time: '1 minggu lalu', desc: 'Ruangguru mencari Digital Marketing Intern...', req: ['Memahami digital marketing','Kreatif & inovatif','Familiar dengan media sosial'], resp: ['Membuat konten digital','Mengelola media sosial','Analisis performa kampanye'], saved: false },
    { id: 5, title: 'Software Engineer Intern', company: 'Traveloka', logo: '🔷', location: 'Jakarta, Indonesia', type: 'Magang', time: '2 hari lalu', desc: 'Traveloka mencari Software Engineer Intern...', req: ['Menguasai satu bahasa pemrograman','Familiar dengan Git','Logika pemrograman kuat'], resp: ['Develop fitur baru','Code review','Kolaborasi dengan tim engineering'], saved: false },
    { id: 6, title: 'Marketing Intern', company: 'Shopee', logo: '🟠', location: 'Bandung, Indonesia', type: 'Magang', time: '4 hari lalu', desc: 'Shopee membuka posisi Marketing Intern...', req: ['Kreatif & analitis','Pengalaman organisasi','Komunikasi baik'], resp: ['Campaign management','Koordinasi antar divisi','Laporan performa marketing'], saved: false },
    { id: 7, title: 'Frontend Developer', company: 'Bukalapak', logo: '🔴', location: 'Remote', type: 'Full-time', time: '1 hari lalu', desc: 'Bukalapak membuka posisi Frontend Developer senior...', req: ['Pengalaman min 2 tahun','Menguasai React/Vue','Familiar dengan REST API'], resp: ['Build & maintain web apps','Kolaborasi dengan backend','Optimasi performa'], saved: false },
    { id: 8, title: 'UX Researcher', company: 'Grab', logo: '🟢', location: 'Remote', type: 'Remote', time: '6 hari lalu', desc: 'Grab mencari UX Researcher untuk bergabung...', req: ['Pengalaman research min 1 tahun','Menguasai metode riset','Kemampuan analisis kualitatif & kuantitatif'], resp: ['Conduct user interviews','Synthesize research findings','Present insights ke tim produk'], saved: false },
  ],
  skills: [
    { id: 1, title: 'UI/UX Design Fundamentals', icon: '🎨', category: 'UIUX Design', level: 'Beginner', score: 82, questions: [
      { q: 'Apa kepanjangan dari UI?', opts: ['User Interface','Universal Integration','Unique Interface','User Interaction'], ans: 0 },
      { q: 'Prinsip utama desain UX adalah?', opts: ['Membuat tampilan cantik','Memenuhi kebutuhan pengguna','Menggunakan banyak warna','Menambah banyak fitur'], ans: 1 },
      { q: 'Wireframe digunakan untuk?', opts: ['Membuat desain final','Menampilkan prototype yang sudah jadi','Membuat kerangka layout awal','Menulis kode HTML'], ans: 2 },
      { q: 'Apa itu usability testing?', opts: ['Testing performa server','Menguji kemudahan penggunaan produk oleh user','Testing keamanan aplikasi','Menguji kecepatan loading'], ans: 1 },
      { q: 'Figma adalah tools untuk?', opts: ['Coding','Desain UI/UX kolaboratif','Manajemen database','Analisis data'], ans: 1 },
    ]},
    { id: 2, title: 'Figma Advanced', icon: '✏️', category: 'UIUX Design', level: 'Advanced', score: 0, questions: [
      { q: 'Fitur Auto Layout di Figma digunakan untuk?', opts: ['Membuat animasi','Mengatur komponen secara otomatis dan responsif','Export gambar','Membuat grid'], ans: 1 },
      { q: 'Component variants di Figma adalah?', opts: ['Beberapa versi komponen dalam satu set','Warna komponen','Ukuran font komponen','Layer komponen'], ans: 0 },
      { q: 'Prototyping di Figma memungkinkan?', opts: ['Coding langsung','Simulasi interaksi antar frame','Deploy ke production','Testing backend'], ans: 1 },
    ]},
    { id: 3, title: 'Problem Solving', icon: '🧩', category: 'UIUX Design', level: 'Intermediate', score: 75, questions: [
      { q: 'Root cause analysis bertujuan untuk?', opts: ['Menemukan akar penyebab masalah','Membuat solusi cepat','Menghindari masalah','Mendokumentasikan bug'], ans: 0 },
      { q: 'Design thinking terdiri dari berapa tahap utama?', opts: ['3','4','5','6'], ans: 2 },
    ]},
    { id: 4, title: 'Communication', icon: '💬', category: 'UIUX Design', level: 'Intermediate', score: 68, questions: [
      { q: 'Active listening artinya?', opts: ['Berbicara banyak','Mendengarkan dengan penuh perhatian','Menyela pembicaraan','Merekam percakapan'], ans: 1 },
      { q: 'Dalam presentasi, apa yang paling penting?', opts: ['Slide yang indah','Pesan yang jelas dan mudah dipahami','Durasi yang panjang','Banyak data'], ans: 1 },
    ]},
    { id: 5, title: 'Python Basics', icon: '🐍', category: 'Programming', level: 'Beginner', score: 0, questions: [
      { q: 'Untuk mencetak output di Python menggunakan?', opts: ['console.log()','print()','echo','System.out.println()'], ans: 1 },
      { q: 'Tipe data list di Python ditulis dengan?', opts: ['{}','()','[]','<>'], ans: 2 },
    ]},
    { id: 6, title: 'Digital Marketing', icon: '📱', category: 'Marketing', level: 'Beginner', score: 55, questions: [
      { q: 'SEO singkatan dari?', opts: ['Search Engine Optimization','Social Engine Optimization','Search Engine Operation','Social Engagement Online'], ans: 0 },
      { q: 'KPI dalam marketing adalah?', opts: ['Key Performance Indicator','Key Product Information','Key Performance Integration','Key Process Indicator'], ans: 0 },
    ]},
  ],
  articles: [
    { id: 1, title: '5 Cara Membuat CV yang Menarik HR', cat: 'Career Tips', icon: '📝', date: '20 Mei 2024', read: '5 menit baca', body: 'CV yang menarik adalah kunci pertama untuk lolos seleksi awal. Berikut adalah lima cara untuk membuat CV kamu standout di antara ratusan pelamar lain. Pertama, gunakan format yang bersih dan mudah dibaca. Kedua, sesuaikan CV dengan deskripsi pekerjaan. Ketiga, cantumkan pencapaian terukur bukan hanya tanggung jawab. Keempat, pastikan tidak ada typo atau kesalahan grammar. Kelima, gunakan kata kunci yang relevan dengan industri yang kamu tuju.', saved: false },
    { id: 2, title: 'Tips Interview Kerja untuk Fresh Graduate', cat: 'Interview', icon: '🎤', date: '19 Mei 2024', read: '4 menit baca', body: 'Fresh graduate sering merasa gugup saat interview pertama. Beberapa tips yang dapat membantu: Riset mendalam tentang perusahaan sebelum interview, persiapkan jawaban untuk pertanyaan umum seperti "ceritakan tentang dirimu", berlatih dengan mock interview, berpakaian profesional dan datang tepat waktu, serta tunjukkan antusiasme dan keinginan belajar yang tinggi. Ingat, interviewer tidak hanya menilai skill teknis tapi juga attitude dan culture fit.', saved: false },
    { id: 3, title: 'Skill Digital yang Paling Dicari di 2024', cat: 'Skill Development', icon: '💻', date: '15 Mei 2024', read: '6 menit baca', body: 'Tahun 2024 membawa perubahan signifikan dalam lanskap ketenagakerjaan digital. Skill yang paling banyak dicari antara lain: AI & Machine Learning, Data Analysis, Cybersecurity, Cloud Computing, UI/UX Design, dan Digital Marketing. Investasikan waktu untuk mempelajari setidaknya satu skill teknis yang relevan dengan bidang yang kamu minati. Platform seperti Coursera, Udemy, dan LinkedIn Learning menawarkan kursus berkualitas yang dapat meningkatkan daya saingmu.', saved: false },
    { id: 4, title: 'Cara Membangun Personal Branding di LinkedIn', cat: 'Career Growth', icon: '🌟', date: '10 Mei 2024', read: '5 menit baca', body: 'Personal branding di LinkedIn sangat penting di era digital ini. Mulai dengan foto profil profesional, headline yang menarik, dan ringkasan yang mencerminkan nilai dan keahlianmu. Aktif berbagi konten yang relevan dengan industrimu, berinteraksi dengan konten orang lain, dan bangun jaringan secara strategis. Mintalah rekomendasi dari rekan kerja atau dosen yang mengenal kamu dengan baik.', saved: false },
    { id: 5, title: 'Cara Negosiasi Gaji dengan Percaya Diri', cat: 'Career Tips', icon: '💰', date: '8 Mei 2024', read: '4 menit baca', body: 'Negosiasi gaji adalah skill yang jarang dilatih tapi sangat penting. Sebelum negosiasi, riset kisaran gaji untuk posisi tersebut di industri yang sama. Saat diminta ekspektasi gaji, berikan angka spesifik berdasarkan riset, bukan mengatakan "terserah" atau "sesuai standar perusahaan". Jelaskan nilai yang kamu bawa ke perusahaan dan kenapa kamu layak mendapatkan angka tersebut.', saved: false },
    { id: 6, title: 'Cara Mengolah Waktu Saat Kuliah dan Magang', cat: 'Career Growth', icon: '⏰', date: '5 Mei 2024', read: '3 menit baca', body: 'Menjalani kuliah sambil magang membutuhkan manajemen waktu yang baik. Gunakan metode time-blocking untuk mengatur jadwal, prioritaskan tugas berdasarkan urgensi dan pentingnya, manfaatkan teknologi seperti Notion atau Google Calendar, dan jangan lupakan waktu untuk istirahat dan menjaga kesehatan mental.', saved: false },
  ],
  agenda: [
    { date: '22', month: 'Mei', title: 'Interview dengan Gojek', time: '10.00 – 10.30 WIB', type: 'interview' },
    { date: '24', month: 'Mei', title: 'Tes Online – Data Analyst', time: '13.00 – 14.00 WIB', type: 'assessment' },
    { date: '27', month: 'Mei', title: 'Workshop CV & Portfolio', time: '15.00 – 16.30 WIB', type: 'workshop' },
  ],
  progress: [
    { name: 'Lengkapi Profil', val: 75, color: 'fill-green' },
    { name: 'Kualitas CV', val: 85, color: 'fill-blue' },
    { name: 'Skill Assessment', val: 60, color: 'fill-purple' },
    { name: 'Mock Interview', val: 40, color: 'fill-orange' },
  ],
  mockPositions: [
    { icon: '🎨', title: 'UI/UX Designer', sub: '10 pertanyaan umum' },
    { icon: '📊', title: 'Product Manager', sub: '10 pertanyaan umum' },
    { icon: '💻', title: 'Software Engineer', sub: '10 pertanyaan umum' },
    { icon: '📈', title: 'Data Analyst', sub: '10 pertanyaan umum' },
    { icon: '📱', title: 'Digital Marketing', sub: '10 pertanyaan umum' },
    { icon: '🏦', title: 'Finance Analyst', sub: '10 pertanyaan umum' },
  ],
  mockQuestions: {
    'UI/UX Designer': [
      { q: 'Ceritakan tentang proses desain terakhir yang kamu kerjakan.', tips: ['Gunakan framework STAR (Situation, Task, Action, Result)','Jelaskan tools yang kamu gunakan','Sebutkan tantangan dan cara mengatasinya'] },
      { q: 'Bagaimana kamu menangani feedback yang berbeda dari stakeholder?', tips: ['Tunjukkan kemampuan komunikasi','Jelaskan bagaimana kamu memprioritaskan feedback','Berikan contoh konkret'] },
      { q: 'Apa perbedaan antara UX Research kualitatif dan kuantitatif?', tips: ['Jelaskan dengan contoh nyata','Sebutkan kapan menggunakan masing-masing','Tunjukkan pemahaman mendalam'] },
      { q: 'Bagaimana kamu memastikan desainmu aksesibel untuk semua pengguna?', tips: ['Sebutkan standar WCAG','Contohkan implementasi aksesibilitas','Tunjukkan kepedulian terhadap inklusivitas'] },
      { q: 'Ceritakan tentang project yang paling menantang dan apa yang kamu pelajari.', tips: ['Jujur tentang kesulitan','Fokus pada pelajaran yang dipetik','Tunjukkan growth mindset'] },
    ],
    'Product Manager': [
      { q: 'Bagaimana kamu memprioritaskan fitur dalam product roadmap?', tips: ['Gunakan framework prioritisasi (RICE, MoSCoW, dll)','Pertimbangkan impact vs effort','Sebutkan peran stakeholder'] },
      { q: 'Ceritakan tentang produk yang gagal dan apa pelajarannya.', tips: ['Berani mengakui kegagalan','Fokus pada learnings','Tunjukkan kemampuan refleksi'] },
      { q: 'Bagaimana kamu mendefinisikan success metrics untuk sebuah fitur?', tips: ['Hubungkan dengan business goals','Sebutkan metrik kuantitatif dan kualitatif','Berikan contoh spesifik'] },
    ],
    'Software Engineer': [
      { q: 'Jelaskan konsep OOP dengan contoh sederhana.', tips: ['Gunakan analogi yang mudah dipahami','Sebutkan 4 pilar OOP','Berikan contoh kode jika perlu'] },
      { q: 'Bagaimana kamu menangani bug yang sulit direproduksi?', tips: ['Jelaskan proses debugging sistematis','Sebutkan tools yang kamu gunakan','Tunjukkan pendekatan metodis'] },
      { q: 'Apa itu REST API dan bagaimana cara kerjanya?', tips: ['Jelaskan HTTP methods','Sebutkan prinsip REST','Berikan contoh use case'] },
    ],
    'Data Analyst': [
      { q: 'Bagaimana kamu membersihkan data yang kotor?', tips: ['Sebutkan langkah-langkah konkret','Tools yang digunakan (Python, SQL, dll)','Pentingnya data validation'] },
      { q: 'Ceritakan tentang analisis data yang memberikan insight bisnis penting.', tips: ['Gunakan format STAR','Sebutkan metode analisis','Tunjukkan impact bisnis'] },
      { q: 'Apa perbedaan antara korelasi dan kausalitas?', tips: ['Jelaskan dengan contoh sederhana','Tunjukkan pemahaman statistik dasar','Berikan contoh kesalahan umum'] },
    ],
    'Digital Marketing': [
      { q: 'Bagaimana kamu mengukur keberhasilan sebuah kampanye digital?', tips: ['Sebutkan KPI yang relevan','Jelaskan tools analitik yang kamu gunakan','Hubungkan dengan business objectives'] },
      { q: 'Ceritakan strategi konten media sosial yang pernah berhasil.', tips: ['Jelaskan target audiensnya','Bagaimana kamu mengukur hasilnya','Sebutkan platform yang digunakan'] },
      { q: 'Apa yang kamu lakukan jika campaign yang berjalan tidak mencapai target?', tips: ['Tunjukkan kemampuan problem-solving','Jelaskan proses analisis kegagalan','Sebutkan langkah perbaikan'] },
    ],
    'Finance Analyst': [
      { q: 'Jelaskan perbedaan antara cash flow dan profit.', tips: ['Gunakan contoh sederhana','Jelaskan pentingnya cash flow','Hubungkan dengan kesehatan bisnis'] },
      { q: 'Bagaimana kamu membuat financial forecast?', tips: ['Sebutkan asumsi yang digunakan','Tools yang kamu gunakan','Cara menangani ketidakpastian'] },
      { q: 'Apa itu NPV dan bagaimana cara menghitungnya?', tips: ['Jelaskan konsep time value of money','Berikan contoh perhitungan sederhana','Sebutkan kapan NPV digunakan'] },
    ],
  },
  riwayat: [
    { title: 'UI/UX Design Interview', date: '18 Nov 2024', score: 85 },
    { title: 'Product Manager Interview', date: '5 Nov 2024', score: 78 },
    { title: 'General Interview', date: '19 Okt 2024', score: 80 },
  ],
  savedJobs: [],
  savedArticles: [],
  settings: {
    akun: { nama: 'Amanda Putri', email: 'amandaputri@email.com', tel: '+62 812-3456-7890', kota: 'Jakarta' },
    notif: { emailLowongan: true, emailArtikel: false, pushInterview: true, pushDeadline: true },
    privasi: { profilePublic: true, cvPublic: false },
    preferensi: { bidang: 'UI/UX Design', tipe: 'Magang', lokasiPref: 'Jakarta' },
  },
};

// ===================== STATE =====================
const state = {
  currentPage: 'beranda',
  currentSkillQuiz: null,
  quizCurrent: 0,
  quizScore: 0,
  interviewPosition: null,
  interviewCurrent: 0,
  interviewAnswers: [],
  currentSettingsTab: 'akun',
  currentSimpananTab: 'lowongan',
};

// ===================== UTILITIES =====================
function $(sel) { return document.querySelector(sel); }
function $$(sel) { return document.querySelectorAll(sel); }
function el(tag, cls, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html) e.innerHTML = html;
  return e;
}
function showToast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2800);
}
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

// ===================== NAV =====================
function navigateTo(page) {
  if (!page) return;
  state.currentPage = page;
  $$('.page').forEach(p => p.classList.remove('active'));
  $$('.nav-item').forEach(n => n.classList.remove('active'));
  const pageEl = document.getElementById('page-' + page);
  const navEl = document.querySelector(`.nav-item[data-page="${page}"]`);
  if (pageEl) pageEl.classList.add('active');
  if (navEl) navEl.classList.add('active');
  // Close sidebar on mobile
  $('#sidebar').classList.remove('open');
  $('.sidebar-overlay') && $('.sidebar-overlay').classList.remove('open');
  window.scrollTo(0, 0);
}

// ===================== BERANDA =====================
function renderBeranda() {
  // Jobs
  const container = $('#berandaJobs');
  if (container) {
    container.innerHTML = '';
    DATA.jobs.slice(0, 4).forEach(j => {
      container.appendChild(buildJobCard(j, true));
    });
  }
  // Artikel
  const aContainer = $('#berandaArtikel');
  if (aContainer) {
    aContainer.innerHTML = '';
    DATA.articles.slice(0, 4).forEach(a => {
      aContainer.appendChild(buildArtikelCard(a, true));
    });
  }
  // Agenda
  const agContainer = $('#agendaList');
  if (agContainer) {
    agContainer.innerHTML = '';
    DATA.agenda.forEach(ag => {
      const item = el('div', 'agenda-item');
      item.innerHTML = `
        <div>
          <div class="agenda-date">${ag.date}</div>
          <div class="agenda-month">${ag.month}</div>
        </div>
        <div style="flex:1">
          <div class="agenda-title">${ag.title}</div>
          <div class="agenda-time">🕐 ${ag.time}</div>
        </div>
        <span class="agenda-badge badge-${ag.type}">${ag.type === 'interview' ? 'Interview' : ag.type === 'assessment' ? 'Assessment' : 'Workshop'}</span>
      `;
      agContainer.appendChild(item);
    });
  }
  // Progress
  const progContainer = $('#progressList');
  if (progContainer) {
    progContainer.innerHTML = '';
    DATA.progress.forEach(p => {
      const item = el('div', 'progress-item');
      item.innerHTML = `
        <div class="progress-label">
          <span class="progress-name">${p.name}</span>
          <span class="progress-val">${p.val}%</span>
        </div>
        <div class="progress-bar-bg">
          <div class="progress-bar-fill ${p.color}" style="width:${p.val}%"></div>
        </div>
      `;
      progContainer.appendChild(item);
    });
  }
  // Saved mini
  const savedMini = $('#savedMini');
  if (savedMini) {
    savedMini.innerHTML = '';
    const allSaved = [...DATA.jobs.filter(j => j.saved).slice(0, 3)];
    if (allSaved.length === 0) {
      savedMini.innerHTML = '<div style="font-size:0.82rem;color:var(--text-muted);text-align:center;padding:12px 0">Belum ada yang disimpan</div>';
    } else {
      allSaved.forEach(j => {
        const item = el('div', 'saved-item');
        item.innerHTML = `
          <div class="saved-item-icon">${j.logo}</div>
          <div style="flex:1"><div class="saved-item-title">${j.title}</div><div class="saved-item-sub">${j.company}</div></div>
          <div class="saved-item-time">${j.time}</div>
        `;
        item.onclick = () => openJobModal(j);
        savedMini.appendChild(item);
      });
    }
  }
}

// ===================== JOB CARDS =====================
function buildJobCard(job, mini = false) {
  const card = el('div', 'job-card');
  card.innerHTML = `
    <button class="job-save-btn" data-id="${job.id}">${job.saved ? '🔖' : '🤍'}</button>
    <div class="job-card-logo">${job.logo}</div>
    <div class="job-card-title">${job.title}</div>
    <div class="job-card-company">${job.company}</div>
    <div class="job-card-loc">📍 ${job.location}</div>
    <span class="job-tag tag-${job.type === 'Magang' ? 'magang' : job.type === 'Full-time' ? 'fulltime' : job.type === 'Remote' ? 'remote' : 'parttime'}">${job.type}</span>
    <div class="job-card-time">${job.time}</div>
  `;
  card.querySelector('.job-save-btn').addEventListener('click', (e) => {
    e.stopPropagation();
    toggleSaveJob(job.id);
    renderBeranda();
    renderLowongan();
  });
  card.addEventListener('click', () => openJobModal(job));
  return card;
}

function toggleSaveJob(id) {
  const job = DATA.jobs.find(j => j.id === id);
  if (!job) return;
  job.saved = !job.saved;
  showToast(job.saved ? `🔖 ${job.title} disimpan!` : `✕ Hapus dari simpanan`);
  renderSimpanan();
}

function openJobModal(job) {
  $('#jobModalTitle').textContent = job.title;
  $('#jobModalBody').innerHTML = `
    <div class="job-detail-header">
      <div class="job-detail-logo">${job.logo}</div>
      <div class="job-detail-info">
        <h2>${job.title}</h2>
        <p>${job.company} · ${job.location}</p>
      </div>
    </div>
    <div class="job-detail-tags">
      <span class="job-tag tag-${job.type === 'Magang' ? 'magang' : job.type === 'Full-time' ? 'fulltime' : job.type === 'Remote' ? 'remote' : 'parttime'}">${job.type}</span>
      <span style="font-size:0.78rem;color:var(--text-muted)">⏰ ${job.time}</span>
    </div>
    <div class="job-detail-section">
      <h3>Deskripsi Pekerjaan</h3>
      <p style="font-size:0.88rem;color:var(--text-secondary)">${job.desc}</p>
    </div>
    <div class="job-detail-section">
      <h3>Kualifikasi</h3>
      <ul>${job.req.map(r => `<li>${r}</li>`).join('')}</ul>
    </div>
    <div class="job-detail-section">
      <h3>Tanggung Jawab</h3>
      <ul>${job.resp.map(r => `<li>${r}</li>`).join('')}</ul>
    </div>
    <div class="apply-actions">
      <button class="btn-primary" onclick="applyJob(${job.id})">Lamar Sekarang</button>
      <button class="btn-outline" onclick="toggleSaveJob(${job.id});renderLowongan();renderBeranda();">${job.saved ? '🔖 Tersimpan' : '🤍 Simpan'}</button>
    </div>
  `;
  openModal('jobModal');
}

function applyJob(id) {
  const job = DATA.jobs.find(j => j.id === id);
  closeModal('jobModal');
  showToast(`✅ Berhasil melamar ke ${job.company}!`);
}

// ===================== LOWONGAN =====================
function renderLowongan(filter = 'semua', searchVal = '') {
  const grid = $('#jobGrid');
  if (!grid) return;
  grid.innerHTML = '';
  let jobs = DATA.jobs;
  if (filter !== 'semua') jobs = jobs.filter(j => j.type === filter);
  if (searchVal) jobs = jobs.filter(j =>
    j.title.toLowerCase().includes(searchVal.toLowerCase()) ||
    j.company.toLowerCase().includes(searchVal.toLowerCase())
  );
  jobs.forEach(j => grid.appendChild(buildJobCard(j)));
  if (jobs.length === 0) {
    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:48px;color:var(--text-muted)">😕 Tidak ada lowongan ditemukan</div>';
  }
}

// ===================== SKILL =====================
function renderSkills(cat = 'all') {
  const grid = $('#skillGrid');
  if (!grid) return;
  grid.innerHTML = '';
  let skills = DATA.skills;
  if (cat !== 'all') skills = skills.filter(s => s.category === cat);
  skills.forEach(s => {
    const card = el('div', 'skill-card');
    card.innerHTML = `
      <div class="skill-card-header">
        <div class="skill-card-icon">${s.icon}</div>
        <div>
          <div class="skill-card-title">${s.title}</div>
          <div class="skill-card-sub">${s.questions.length} pertanyaan</div>
        </div>
      </div>
      <span class="skill-level-badge level-${s.level.toLowerCase()}">${s.level}</span>
      ${s.score > 0 ? `
        <div class="skill-score">
          <span>Skor Terakhir</span>
          <span class="skill-score-val">${s.score}%</span>
        </div>
        <div class="progress-bar-bg"><div class="progress-bar-fill fill-purple" style="width:${s.score}%"></div></div>
      ` : '<div style="font-size:0.8rem;color:var(--text-muted)">Belum pernah dikerjakan</div>'}
      <button class="btn-mulai">Mulai Assessment →</button>
    `;
    card.querySelector('.btn-mulai').addEventListener('click', () => startQuiz(s));
    grid.appendChild(card);
  });
}

function startQuiz(skill) {
  state.currentSkillQuiz = skill;
  state.quizCurrent = 0;
  state.quizScore = 0;
  $('#quizTitle').textContent = `Quiz: ${skill.title}`;
  renderQuizQuestion();
  openModal('quizModal');
}

function renderQuizQuestion() {
  const skill = state.currentSkillQuiz;
  const qIdx = state.quizCurrent;
  const total = skill.questions.length;
  const body = $('#quizBody');
  if (qIdx >= total) {
    const pct = Math.round((state.quizScore / total) * 100);
    body.innerHTML = `
      <div class="quiz-result">
        <div class="quiz-result-score">${pct}%</div>
        <div class="quiz-result-label">${pct >= 80 ? '🎉 Luar Biasa!' : pct >= 60 ? '👍 Cukup Baik!' : '📚 Perlu Belajar Lagi'}</div>
        <p style="color:var(--text-secondary);font-size:0.88rem;margin-bottom:20px">Kamu menjawab benar ${state.quizScore} dari ${total} pertanyaan</p>
        <button class="btn-primary" onclick="finishQuiz(${pct})">Selesai & Simpan Skor</button>
      </div>
    `;
    return;
  }
  const q = skill.questions[qIdx];
  body.innerHTML = `
    <div class="quiz-progress">
      <span style="font-size:0.82rem;color:var(--text-muted)">Pertanyaan ${qIdx + 1} dari ${total}</span>
      <div class="quiz-progress-bar"><div class="quiz-progress-fill" style="width:${((qIdx)/total)*100}%"></div></div>
    </div>
    <div class="quiz-question">${q.q}</div>
    <div class="quiz-options" id="quizOpts"></div>
  `;
  const optsContainer = $('#quizOpts');
  q.opts.forEach((opt, i) => {
    const btn = el('button', 'quiz-option', opt);
    btn.addEventListener('click', () => answerQuiz(i, q.ans, btn));
    optsContainer.appendChild(btn);
  });
}

function answerQuiz(chosen, correct, btn) {
  const opts = $$('#quizOpts .quiz-option');
  opts.forEach(o => o.disabled = true);
  if (chosen === correct) {
    btn.classList.add('correct');
    state.quizScore++;
  } else {
    btn.classList.add('wrong');
    opts[correct].classList.add('correct');
  }
  setTimeout(() => {
    state.quizCurrent++;
    renderQuizQuestion();
  }, 1000);
}

function finishQuiz(pct) {
  const skill = DATA.skills.find(s => s.id === state.currentSkillQuiz.id);
  if (skill) skill.score = pct;
  closeModal('quizModal');
  renderSkills($('.skill-cat.active')?.dataset.cat || 'all');
  showToast(`🎯 Skor ${pct}% tersimpan untuk ${state.currentSkillQuiz.title}`);
}

// ===================== MOCK INTERVIEW =====================
function renderMockPositions() {
  const container = $('#mockPositions');
  if (!container) return;
  container.innerHTML = '';
  DATA.mockPositions.forEach(pos => {
    const card = el('div', 'mock-pos-card');
    card.innerHTML = `
      <div class="mock-pos-icon">${pos.icon}</div>
      <div class="mock-pos-title">${pos.title}</div>
      <div class="mock-pos-sub">${pos.sub}</div>
    `;
    card.addEventListener('click', () => startInterview(pos.title));
    container.appendChild(card);
  });
  const rContainer = $('#riwayatList');
  if (!rContainer) return;
  rContainer.innerHTML = '';
  DATA.riwayat.forEach(r => {
    const item = el('div', 'riwayat-item');
    item.innerHTML = `
      <span style="font-size:1.2rem">🎤</span>
      <div class="riwayat-title">${r.title}</div>
      <div class="riwayat-date">${r.date}</div>
      <div class="riwayat-score">${r.score}</div>
    `;
    rContainer.appendChild(item);
  });
}

function startInterview(position) {
  state.interviewPosition = position;
  state.interviewCurrent = 0;
  state.interviewAnswers = [];
  $('#interviewTitle').textContent = `Interview: ${position}`;
  renderInterviewQuestion();
  openModal('interviewModal');
}

function renderInterviewQuestion() {
  const qs = DATA.mockQuestions[state.interviewPosition] || DATA.mockQuestions['UI/UX Designer'];
  const idx = state.interviewCurrent;
  const total = qs.length;
  const body = $('#interviewBody');
  if (idx >= total) {
    const score = 70 + Math.floor(Math.random() * 25);
    DATA.riwayat.unshift({ title: state.interviewPosition + ' Interview', date: new Date().toLocaleDateString('id-ID', {day:'numeric',month:'short',year:'numeric'}), score });
    body.innerHTML = `
      <div class="quiz-result">
        <div class="quiz-result-score">${score}</div>
        <div class="quiz-result-label">${score >= 85 ? '🎉 Excellent!' : score >= 75 ? '👍 Good Job!' : '📈 Keep Practicing!'}</div>
        <p style="color:var(--text-secondary);font-size:0.88rem;margin-bottom:20px">Kamu telah menyelesaikan ${total} pertanyaan interview untuk posisi ${state.interviewPosition}.</p>
        <button class="btn-primary" onclick="closeModal('interviewModal');renderMockPositions()">Lihat Riwayat</button>
      </div>
    `;
    return;
  }
  const q = qs[idx];
  body.innerHTML = `
    <div style="font-size:0.82rem;color:var(--text-muted);margin-bottom:12px">Pertanyaan ${idx + 1} dari ${total}</div>
    <div class="quiz-progress-bar" style="margin-bottom:20px"><div class="quiz-progress-fill" style="width:${(idx/total)*100}%"></div></div>
    <div class="interview-question">${q.q}</div>
    <div class="interview-tips">
      <p style="font-weight:600;font-size:0.85rem;color:var(--text-primary);margin-bottom:8px">💡 Tips Menjawab:</p>
      <ul>${q.tips.map(t => `<li>${t}</li>`).join('')}</ul>
    </div>
    <textarea class="answer-area" id="answerArea" placeholder="Tuliskan jawaban kamu di sini..."></textarea>
    <div class="interview-nav">
      <span class="interview-counter">${idx + 1} / ${total}</span>
      <button class="btn-primary" onclick="nextInterview()">
        ${idx === total - 1 ? 'Selesai ✓' : 'Pertanyaan Berikutnya →'}
      </button>
    </div>
  `;
}

function nextInterview() {
  const ans = $('#answerArea')?.value || '';
  state.interviewAnswers.push(ans);
  state.interviewCurrent++;
  renderInterviewQuestion();
}

// ===================== ARTIKEL =====================
function buildArtikelCard(a, mini = false) {
  const colors = ['#EDE9FF','#DCFCE7','#FEF3C7','#FEE2E2','#DBEAFE','#FCE7F3'];
  const colorIdx = a.id % colors.length;
  const card = el('div', 'artikel-card');
  card.innerHTML = `
    <div class="artikel-card-img" style="background:${colors[colorIdx]}">${a.icon}</div>
    <div class="artikel-card-body">
      <span class="artikel-cat">${a.cat}</span>
      <div class="artikel-card-title">${a.title}</div>
      <div class="artikel-card-meta">
        <span>📅 ${a.date}</span>
        <span>⏱ ${a.read}</span>
      </div>
    </div>
  `;
  card.addEventListener('click', () => openArtikelModal(a));
  return card;
}

function renderArtikel(cat = 'all') {
  const grid = $('#artikelGrid');
  if (!grid) return;
  grid.innerHTML = '';
  let articles = DATA.articles;
  if (cat !== 'all') articles = articles.filter(a => a.cat === cat);
  articles.forEach(a => grid.appendChild(buildArtikelCard(a)));
}

function openArtikelModal(a) {
  const colors = ['#EDE9FF','#DCFCE7','#FEF3C7','#FEE2E2','#DBEAFE','#FCE7F3'];
  $('#artikelModalTitle').textContent = a.title;
  $('#artikelModalBody').innerHTML = `
    <div class="artikel-detail-img" style="background:${colors[a.id % colors.length]}">${a.icon}</div>
    <div class="artikel-detail-meta">
      <span class="artikel-cat">${a.cat}</span>
      <span>📅 ${a.date}</span>
      <span>⏱ ${a.read}</span>
    </div>
    <div class="artikel-detail-title">${a.title}</div>
    <div class="artikel-detail-body">
      ${a.body.split('\n').map(p => `<p>${p}</p>`).join('')}
    </div>
    <div style="display:flex;gap:10px;margin-top:20px">
      <button class="btn-primary" onclick="saveArtikel(${a.id})">🔖 Simpan Artikel</button>
      <button class="btn-outline" onclick="closeModal('artikelModal')">Tutup</button>
    </div>
  `;
  openModal('artikelModal');
}

function saveArtikel(id) {
  const a = DATA.articles.find(x => x.id === id);
  if (!a.saved) {
    a.saved = true;
    showToast(`🔖 "${a.title}" disimpan!`);
  } else {
    showToast('Artikel sudah disimpan sebelumnya');
  }
  renderSimpanan();
}

// ===================== SIMPANAN =====================
function renderSimpanan(tab = state.currentSimpananTab) {
  state.currentSimpananTab = tab;
  const grid = $('#simpananGrid');
  if (!grid) return;
  grid.innerHTML = '';
  if (tab === 'lowongan') {
    const saved = DATA.jobs.filter(j => j.saved);
    if (saved.length === 0) {
      grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:48px;color:var(--text-muted)">🔖 Belum ada lowongan yang disimpan</div>';
      return;
    }
    saved.forEach(j => grid.appendChild(buildJobCard(j)));
  } else if (tab === 'artikel') {
    const saved = DATA.articles.filter(a => a.saved);
    if (saved.length === 0) {
      grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:48px;color:var(--text-muted)">🔖 Belum ada artikel yang disimpan</div>';
      return;
    }
    saved.forEach(a => grid.appendChild(buildArtikelCard(a)));
  } else {
    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:48px;color:var(--text-muted)">🏢 Belum ada perusahaan yang disimpan</div>';
  }
}

// ===================== PENGATURAN =====================
function renderSettings(tab = 'akun') {
  state.currentSettingsTab = tab;
  const content = $('#settingsContent');
  if (!content) return;
  $$('.setnav').forEach(b => b.classList.toggle('active', b.dataset.stab === tab));
  if (tab === 'akun') {
    const s = DATA.settings.akun;
    content.innerHTML = `
      <h3 style="font-size:1.05rem;font-weight:700;margin-bottom:20px">Informasi Akun</h3>
      <div style="display:flex;align-items:center;gap:16px;margin-bottom:24px">
        <img src="https://i.pravatar.cc/80?img=47" style="width:80px;height:80px;border-radius:50%;border:3px solid var(--primary-light)">
        <div>
          <div style="font-weight:700;font-size:1rem">${s.nama}</div>
          <div style="font-size:0.82rem;color:var(--text-muted)">${s.email}</div>
          <button class="btn-outline-sm" style="margin-top:8px" onclick="showToast('📷 Fitur ganti foto segera hadir!')">Ganti Foto</button>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Nama Lengkap</label><input class="form-input" id="setNama" value="${s.nama}"/></div>
        <div class="form-group"><label>Email</label><input class="form-input" id="setEmail" value="${s.email}"/></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>No. Telepon</label><input class="form-input" id="setTel" value="${s.tel}"/></div>
        <div class="form-group"><label>Kota</label><input class="form-input" id="setKota" value="${s.kota}"/></div>
      </div>
      <button class="btn-primary" onclick="saveAkun()">Simpan Perubahan</button>
    `;
  } else if (tab === 'notif') {
    const s = DATA.settings.notif;
    content.innerHTML = `
      <h3 style="font-size:1.05rem;font-weight:700;margin-bottom:20px">Notifikasi</h3>
      ${buildToggleRow('Email Lowongan Baru', 'Dapatkan email saat ada lowongan yang sesuai', 'notifEmailLowongan', s.emailLowongan)}
      ${buildToggleRow('Email Artikel Terbaru', 'Dapatkan email saat artikel baru diterbitkan', 'notifEmailArtikel', s.emailArtikel)}
      ${buildToggleRow('Push – Pengingat Interview', 'Notifikasi sebelum jadwal interview', 'notifPushInterview', s.pushInterview)}
      ${buildToggleRow('Push – Deadline Lamaran', 'Notifikasi sebelum batas lamaran habis', 'notifPushDeadline', s.pushDeadline)}
      <div style="margin-top:20px"><button class="btn-primary" onclick="saveNotif()">Simpan Pengaturan</button></div>
    `;
  } else if (tab === 'privasi') {
    const s = DATA.settings.privasi;
    content.innerHTML = `
      <h3 style="font-size:1.05rem;font-weight:700;margin-bottom:20px">Privasi</h3>
      ${buildToggleRow('Profil Publik', 'Siapa saja bisa melihat profilmu', 'toggleProfilPublic', s.profilePublic)}
      ${buildToggleRow('CV Dapat Dilihat Perusahaan', 'Perusahaan dapat melihat CV kamu', 'toggleCVPublic', s.cvPublic)}
      <div style="margin-top:20px"><button class="btn-primary" onclick="savePrivasi()">Simpan Pengaturan</button></div>
    `;
  } else if (tab === 'preferensi') {
    const s = DATA.settings.preferensi;
    content.innerHTML = `
      <h3 style="font-size:1.05rem;font-weight:700;margin-bottom:20px">Preferensi Karir</h3>
      <div class="form-group">
        <label>Bidang yang Diminati</label>
        <select class="form-input" id="prefBidang">
          ${['UI/UX Design','Product Management','Software Engineering','Data Analysis','Digital Marketing','Finance'].map(b => `<option ${s.bidang===b?'selected':''}>${b}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label>Tipe Pekerjaan</label>
        <select class="form-input" id="prefTipe">
          ${['Magang','Full-time','Part-time','Remote'].map(t => `<option ${s.tipe===t?'selected':''}>${t}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label>Lokasi Preferred</label>
        <select class="form-input" id="prefLokasi">
          ${['Jakarta','Bandung','Surabaya','Remote','Lainnya'].map(l => `<option ${s.lokasiPref===l?'selected':''}>${l}</option>`).join('')}
        </select>
      </div>
      <button class="btn-primary" onclick="savePreferensi()">Simpan Preferensi</button>
    `;
  }
}

function buildToggleRow(label, sub, id, checked) {
  return `
    <div class="toggle-row">
      <div>
        <div class="toggle-label">${label}</div>
        <div class="toggle-sub">${sub}</div>
      </div>
      <label class="toggle">
        <input type="checkbox" id="${id}" ${checked ? 'checked' : ''}/>
        <span class="toggle-slider"></span>
      </label>
    </div>
  `;
}

function saveAkun() {
  DATA.settings.akun.nama = $('#setNama')?.value || DATA.settings.akun.nama;
  DATA.settings.akun.email = $('#setEmail')?.value || DATA.settings.akun.email;
  DATA.settings.akun.tel = $('#setTel')?.value || DATA.settings.akun.tel;
  DATA.settings.akun.kota = $('#setKota')?.value || DATA.settings.akun.kota;
  showToast('✅ Akun berhasil diperbarui!');
}
function saveNotif() {
  DATA.settings.notif.emailLowongan = $('#notifEmailLowongan')?.checked;
  DATA.settings.notif.emailArtikel = $('#notifEmailArtikel')?.checked;
  DATA.settings.notif.pushInterview = $('#notifPushInterview')?.checked;
  DATA.settings.notif.pushDeadline = $('#notifPushDeadline')?.checked;
  showToast('✅ Pengaturan notifikasi disimpan!');
}
function savePrivasi() {
  DATA.settings.privasi.profilePublic = $('#toggleProfilPublic')?.checked;
  DATA.settings.privasi.cvPublic = $('#toggleCVPublic')?.checked;
  showToast('✅ Pengaturan privasi disimpan!');
}
function savePreferensi() {
  DATA.settings.preferensi.bidang = $('#prefBidang')?.value || '';
  DATA.settings.preferensi.tipe = $('#prefTipe')?.value || '';
  DATA.settings.preferensi.lokasiPref = $('#prefLokasi')?.value || '';
  showToast('✅ Preferensi karir disimpan!');
}

// ===================== CV =====================
function renderCVTemplates() {
  const container = $('#cvTemplates');
  if (!container) return;
  const templates = ['Modern', 'Klasik', 'Kreatif', 'Minimalis', 'ATS-Friendly', 'Bold'];
  container.innerHTML = '';
  templates.forEach((t, i) => {
    const item = el('div', `template-item${i === 0 ? ' selected' : ''}`, t);
    item.addEventListener('click', () => {
      $$('.template-item').forEach(x => x.classList.remove('selected'));
      item.classList.add('selected');
      showToast(`✅ Template "${t}" dipilih`);
    });
    container.appendChild(item);
  });
}

// ===================== EVENTS =====================
document.addEventListener('DOMContentLoaded', () => {
  // Initial renders
  renderBeranda();
  renderLowongan();
  renderSkills();
  renderMockPositions();
  renderArtikel();
  renderSimpanan();
  renderSettings();
  renderCVTemplates();

  // Sidebar navigation
  $$('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      navigateTo(item.dataset.page);
    });
  });

  // Quick access items
  $$('.qa-item').forEach(item => {
    item.addEventListener('click', () => navigateTo(item.dataset.page));
  });

  // Hero button
  document.querySelector('.hero-text .btn-primary')?.addEventListener('click', () => navigateTo('cv'));

  // Link all with data-page
  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-page]');
    if (el && !el.classList.contains('nav-item') && !el.classList.contains('qa-item') && !el.classList.contains('hero-text')) {
      e.preventDefault();
      navigateTo(el.dataset.page);
    }
  });

  // Lowongan search & filter
  const btnCari = $('#btnCariLowongan');
  const jobSearch = $('#jobSearch');
  const jobFilter = $('#jobFilter');
  if (btnCari) btnCari.addEventListener('click', () => {
    renderLowongan($('.ftab.active')?.dataset.filter || 'semua', jobSearch?.value || '');
  });
  if (jobSearch) jobSearch.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') renderLowongan($('.ftab.active')?.dataset.filter || 'semua', jobSearch.value);
  });
  $$('.ftab').forEach(tab => {
    tab.addEventListener('click', () => {
      $$('.ftab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      renderLowongan(tab.dataset.filter, jobSearch?.value || '');
    });
  });

  // Skill categories
  $$('.skill-cat').forEach(cat => {
    cat.addEventListener('click', () => {
      $$('.skill-cat').forEach(c => c.classList.remove('active'));
      cat.classList.add('active');
      renderSkills(cat.dataset.cat);
    });
  });

  // Artikel filter
  $$('.atab').forEach(tab => {
    tab.addEventListener('click', () => {
      $$('.atab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      renderArtikel(tab.dataset.acat);
    });
  });

  // Simpanan tabs
  $$('.stab').forEach(tab => {
    tab.addEventListener('click', () => {
      $$('.stab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      renderSimpanan(tab.dataset.scat);
    });
  });

  // Settings nav
  $$('.setnav').forEach(btn => {
    btn.addEventListener('click', () => {
      renderSettings(btn.dataset.stab);
    });
  });

  // CV buttons
  $('#btnBuatCV')?.addEventListener('click', () => openModal('cvModal'));
  $('#btnLihatCV')?.addEventListener('click', () => openModal('cvModal'));
  $('#btnTingkatCV')?.addEventListener('click', () => openModal('cvModal'));
  $('#btnSimpanCV')?.addEventListener('click', () => {
    closeModal('cvModal');
    showToast('✅ CV berhasil disimpan!');
  });

  // Mock interview start btn
  $('#btnMulaiInterview')?.addEventListener('click', () => {
    const positions = DATA.mockPositions;
    const pos = positions[Math.floor(Math.random() * positions.length)];
    startInterview(pos.title);
  });

  // Modal close buttons
  document.addEventListener('click', (e) => {
    const closeBtn = e.target.closest('.modal-close');
    if (closeBtn) {
      const id = closeBtn.dataset.modal;
      if (id) closeModal(id);
    }
    // Click outside modal
    if (e.target.classList.contains('modal-overlay')) {
      e.target.classList.remove('open');
    }
  });

  // Mobile hamburger
  const hamburger = $('#hamburger');
  const sidebar = $('#sidebar');
  // Create overlay
  const overlay = document.createElement('div');
  overlay.className = 'sidebar-overlay';
  document.body.appendChild(overlay);
  if (hamburger) {
    hamburger.addEventListener('click', () => {
      sidebar.classList.toggle('open');
      overlay.classList.toggle('open');
    });
  }
  overlay.addEventListener('click', () => {
    sidebar.classList.remove('open');
    overlay.classList.remove('open');
  });
});

// Expose global functions for inline onclick
window.applyJob = applyJob;
window.toggleSaveJob = toggleSaveJob;
window.closeModal = closeModal;
window.openModal = openModal;
window.nextInterview = nextInterview;
window.renderMockPositions = renderMockPositions;
window.saveArtikel = saveArtikel;
window.renderLowongan = renderLowongan;
window.renderBeranda = renderBeranda;
window.finishQuiz = finishQuiz;
window.saveAkun = saveAkun;
window.saveNotif = saveNotif;
window.savePrivasi = savePrivasi;
window.savePreferensi = savePreferensi;
window.showToast = showToast;
